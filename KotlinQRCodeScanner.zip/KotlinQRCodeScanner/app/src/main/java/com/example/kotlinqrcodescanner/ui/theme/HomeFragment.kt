package com.example.kotlinqrcodescanner.ui.theme

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

<item
android:id="@+id/menu_open_scanner"
android:title="Open QR Scanner"
android:icon="@drawable/ic_qr_scanner"
android:showAsAction="ifRoom" />

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnOpenScanner = findViewById<Button>(R.id.btnOpenScanner)
        btnOpenScanner.setOnClickListener {
            // Înlocuiește fragmentul curent cu QRScannerFragment
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, QRScannerFragment())
                .addToBackStack(null) // Adaugă în back stack pentru navigare înapoi
                .commit()
        }
    }
}