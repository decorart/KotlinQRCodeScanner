package com.example.kotlinqrcodescanner.ui.theme

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult

class QRScannerFragment : Fragment(R.layout.fragment_qr_scanner) {

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inițializează scanarea QR
        val integrator = IntentIntegrator(requireActivity())
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE) // Setează tipul de cod QR
        integrator.setPrompt("Scanati un cod QR") // Mesajul pe care îl vei vedea
        integrator.setCameraId(0) // Folosește camera principală
        integrator.setBeepEnabled(true) // Poți dezactiva sunetul dacă dorești
        integrator.setBarcodeImageEnabled(true) // Permite salvarea imaginii codului QR
        integrator.initiateScan() // Inițiază scanarea
    }

    // Rezultatul scanării QR
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(requireContext(), "Scanare anulată", Toast.LENGTH_LONG).show()
            } else {
                // Codul QR a fost scanat cu succes
                Toast.makeText(requireContext(), "Cod QR găsit: ${result.contents}", Toast.LENGTH_LONG).show()
                // Aici poți adăuga logică pentru a procesa rezultatul QR
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}